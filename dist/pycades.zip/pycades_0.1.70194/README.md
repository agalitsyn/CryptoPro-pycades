# pycades

pycades представляет собой расширение для Python3. Расширение реализует интерфейс, аналогичный [CAdESCOM](https://docs.cryptopro.ru/cades/reference/cadescom).

[Общая информация](https://docs.cryptopro.ru/cades/pycades)

[Инструкция по сборке](https://docs.cryptopro.ru/cades/pycades/pycades-build)

[Инструкция по установке](https://docs.cryptopro.ru/cades/pycades/pycades-install)

[Пример использования](https://docs.cryptopro.ru/cades/pycades/pycades-samples)